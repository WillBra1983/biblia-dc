/**
 * Ponto de entrada das Cloud Functions do projeto Bíblia DC.
 *
 * Cada arquivo em `src/` exporta uma função; aqui só fazemos o
 * re-export para o runtime do Firebase descobri-las pelo nome.
 */

const admin = require('./src/firebaseAdmin')

if (!admin.apps.length) {
  admin.initializeApp()
}

// Push de chat (RTDB trigger)
exports.pushChatMensagem = require('./src/onMensagemChat').pushChatMensagem

// Aviso administrativo (callable)
exports.enviarAvisoAdmin = require('./src/enviarAvisoAdmin').enviarAvisoAdmin

// Capas da Biblioteca Digital — envio validado exclusivamente para administradores.
exports.enviarCapaBiblioteca = require('./src/bibliotecaCapas').enviarCapaBiblioteca

// Venda direta da Biblioteca por Pix, com conferência e liberação pelo administrador.
const bibliotecaPix = require('./src/bibliotecaPix')
exports.salvarConfiguracaoPixBiblioteca = bibliotecaPix.salvarConfiguracaoPixBiblioteca
exports.criarPedidoPixBiblioteca = bibliotecaPix.criarPedidoPixBiblioteca
exports.informarPagamentoPixBiblioteca = bibliotecaPix.informarPagamentoPixBiblioteca
exports.decidirPedidoPixBiblioteca = bibliotecaPix.decidirPedidoPixBiblioteca

// Arquivos PDF/EPUB privados. O catálogo guarda apenas metadados; o arquivo
// completo é liberado por endereço temporário após conferir o acesso da conta.
const bibliotecaArquivos = require('./src/bibliotecaArquivos')
exports.prepararUploadLivroBiblioteca = bibliotecaArquivos.prepararUploadLivroBiblioteca
exports.confirmarUploadLivroBiblioteca = bibliotecaArquivos.confirmarUploadLivroBiblioteca
exports.obterArquivoLivroBiblioteca = bibliotecaArquivos.obterArquivoLivroBiblioteca
exports.registrarAcessoBiblioteca = require('./src/bibliotecaAcessos').registrarAcessoBiblioteca
exports.listarAcessosBibliotecaAdmin = require('./src/bibliotecaAcessos').listarAcessosBibliotecaAdmin
exports.excluirArquivoLivroBiblioteca = bibliotecaArquivos.excluirArquivoLivroBiblioteca

// Lembretes diários (cron)
exports.lembretesDiarios = require('./src/lembretesDiarios').lembretesDiarios

// Auto-inscrição no topic `novidades` (3 triggers RTDB)
const topicNovidades = require('./src/gerirTopicNovidades')
exports.inscreverTokenNovoNovidades = topicNovidades.inscreverTokenNovoNovidades
exports.desinscreverTokenRemovidoNovidades = topicNovidades.desinscreverTokenRemovidoNovidades
exports.aoMudarPreferenciaNovidades = topicNovidades.aoMudarPreferenciaNovidades

// Opt-in de lançamentos editoriais (3 triggers RTDB; default desligado)
const topicLivros = require('./src/gerirTopicLivros')
exports.inscreverTokenNovoLivros = topicLivros.inscreverTokenNovoLivros
exports.desinscreverTokenRemovidoLivros = topicLivros.desinscreverTokenRemovidoLivros
exports.aoMudarPreferenciaLivros = topicLivros.aoMudarPreferenciaLivros

// Votação em estudos IA (versículo + perícope): 10 positivos → oficial; 10 negativos → descarta candidato
exports.onVotoEstudoCurado = require('./src/onVotoEstudoCurado').onVotoEstudoCurado

// Métricas de visualização por secção (cliente deduplica por entrada; RTDB só admin lê)
exports.registrarVisualizacaoSecao =
  require('./src/registrarVisualizacaoSecao').registrarVisualizacaoSecao

// Lista utilizadores Auth (paginado) — só admin
exports.listarUsuariosAdmin = require('./src/listarUsuariosAdmin').listarUsuariosAdmin

// Presença diária imutável por data — evita reconstruir o passado pelo último acesso.
exports.registrarEntradaDiaria = require('./src/registrarEntradaDiaria').registrarEntradaDiaria
exports.listarAcessosDiariosAdmin =
  require('./src/listarAcessosDiariosAdmin').listarAcessosDiariosAdmin

// Apaga contas e-mail/senha sem verificação após 48 h (cron diário)
exports.limparContasEmailNaoVerificadas =
  require('./src/limparContasEmailNaoVerificadas').limparContasEmailNaoVerificadas

// Cadastro e-mail/senha: pendência até abrir o link (sem utilizador Auth antes disso)
exports.iniciarCadastroEmailSenha = require('./src/cadastroEmailSenha').iniciarCadastroEmailSenha
exports.finalizarCadastroEmailLink = require('./src/cadastroEmailSenha').finalizarCadastroEmailLink
exports.cancelarCadastroEmailPendente = require('./src/cadastroEmailSenha').cancelarCadastroEmailPendente

// Prova bíblica: gabarito só no servidor (aluno)
exports.iniciarProvaBiblicaAluno = require('./src/provaBiblicaAluno').iniciarProvaBiblicaAluno
exports.avaliarProvaBiblicaAluno = require('./src/provaBiblicaAluno').avaliarProvaBiblicaAluno

// Reconstrói índices de busca do chat (userSearch + profileEmails) — só admin
exports.sincronizarIndiceBuscaAdmin =
  require('./src/sincronizarIndiceBuscaAdmin').sincronizarIndiceBuscaAdmin

// Desativar / reativar / apagar utilizador no Auth — só admin
exports.gerenciarUsuarioAdmin = require('./src/gerenciarUsuarioAdmin').gerenciarUsuarioAdmin

// Chat: resolver e-mail → UID (Auth + índice RTDB)
exports.resolverEmailParaUid = require('./src/resolverEmailParaUid').resolverEmailParaUid

// Ranking do plano: espelha progresso de users/{uid}/planoLeitura → planoLeituraRanking/{uid}
exports.onPlanoLeituraRankingSync =
  require('./src/onPlanoLeituraRanking').onPlanoLeituraRankingSync

// Ranking do plano: rebuild sob demanda ao abrir a lista (throttle 7 dias)
exports.atualizarRankingPlanoLeitura =
  require('./src/atualizarRankingPlanoLeitura').atualizarRankingPlanoLeitura

// Versão Android na Play Store → RTDB (aviso in-app); cron + callable admin
exports.sincronizarVersaoPlayStoreAdmin =
  require('./src/sincronizarVersaoPlayStoreAdmin').sincronizarVersaoPlayStoreAdmin
exports.sincronizarVersaoPlayStoreCron =
  require('./src/sincronizarVersaoPlayStoreCron').sincronizarVersaoPlayStoreCron

// Proxy Gemini (chave no servidor; auth + cota por usuário)
exports.geminiGenerateContent = require('./src/geminiProxy').geminiGenerateContent
const analiseTextual = require('./src/analiseTextual')
exports.gerarAnaliseTextual = analiseTextual.gerarAnaliseTextual
exports.avaliarAnaliseTextual = analiseTextual.avaliarAnaliseTextual
exports.revisarAnaliseTextual = analiseTextual.revisarAnaliseTextual

// Versiculo do dia: selecao sem repeticao e publicacao direta na Biblia comentada.
const versiculoDoDia = require('./src/versiculoDoDia')
exports.publicarVersiculoDoDia = versiculoDoDia.publicarVersiculoDoDia
exports.selecionarVersiculoDoDia = versiculoDoDia.selecionarVersiculoDoDia
exports.garantirVersiculoDoDia = versiculoDoDia.garantirVersiculoDoDia
exports.substituirVersiculoDoDia = versiculoDoDia.substituirVersiculoDoDia
exports.prepararVersiculoDoDiaSubstituido = versiculoDoDia.prepararVersiculoDoDiaSubstituido
exports.registrarCompartilhamentoVersiculoDoDia = versiculoDoDia.registrarCompartilhamentoVersiculoDoDia
exports.registrarInteracaoDestaque = require('./src/destaquesInteracoes').registrarInteracaoDestaque
const bibliotecaVisitante = require('./src/bibliotecaVisitante')
exports.catalogoBibliotecaVisitante = bibliotecaVisitante.catalogoBibliotecaVisitante
exports.acessosBibliotecaVisitante = bibliotecaVisitante.acessosBibliotecaVisitante
exports.vincularComprasBibliotecaVisitante = bibliotecaVisitante.vincularComprasBibliotecaVisitante
