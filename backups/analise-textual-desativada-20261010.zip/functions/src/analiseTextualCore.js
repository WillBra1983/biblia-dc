const { createHash } = require('node:crypto')
const VERSAO = 'analise-revisada-5'
const MODALIDADES = ['estudo', 'devocional', 'sermao']
const ETAPAS = ['exegese', 'hermeneutica', 'homiletica']
const hash = (value) => createHash('sha256').update(JSON.stringify(value)).digest('hex')
function normalizarEntrada(data, catalogo) {
  const livro = Number(data.livro), capitulo = Number(data.capitulo)
  const versos = [...new Set((Array.isArray(data.versiculos) ? data.versiculos : []).map(Number))].sort((a, b) => a - b)
  if (!MODALIDADES.includes(data.modalidade) || !ETAPAS.includes(data.etapa) || !versos.length || versos.length > 30 || versos.some(v => !Number.isInteger(v) || v < 1)) throw new Error('Selecione modalidade, etapa e entre 1 e 30 versículos do mesmo capítulo.')
  const contexto = catalogo.filter(v => v.bookId === livro && v.chapter === capitulo)
  const selecionados = versos.map(v => contexto.find(row => row.verse === v))
  if (selecionados.some(v => !v)) throw new Error('Referência bíblica inválida.')
  return { livro, capitulo, versos, selecionados, contexto, modalidade: data.modalidade, etapa: data.etapa }
}
function chaveBase(etapa, verso, dependencia = '', revisaoOriginal = '') {
  return hash([VERSAO, 'ARA', etapa, verso.bookId, verso.chapter, verso.verse, verso.text, dependencia, revisaoOriginal])
}
function chaveRelatorio(entrada, etapa, bases) {
  return hash([VERSAO, etapa, entrada.livro, entrada.capitulo, entrada.versos, etapa === 'homiletica' ? entrada.modalidade : null, bases.map(b => [b.id, hash(b.texto)])])
}
module.exports = { VERSAO, MODALIDADES, ETAPAS, hash, normalizarEntrada, chaveBase, chaveRelatorio }
