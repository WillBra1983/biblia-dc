// Revisão automática é uma barreira adicional, não revisão humana certificada.
const REGRAS = `Produza material completo, preciso e legível em português brasileiro, com orientação reformada, sem fingir certeza onde faltam dados.
Separe explicitamente Dado textual, Conclusão contextual, Inferência (com grau de segurança), Síntese canônica/confessional e Aplicação. Não use o tamanho como medida de profundidade.
Strong identifica lemas; não prova significado, sintaxe ou doutrina. Distinga léxicos locais fornecidos de páginas recuperadas nesta pesquisa. Só atribua uma afirmação a uma página se o dossiê a sustenta; uma documentação de parsing não é um comentário exegético. Não invente bibliografia, trechos ou números de perguntas.
Aoristo descreve aspecto perfectivo, não necessariamente ação pontual; subjuntivo aoristo não é um tempo futuro. Presente particípio tem aspecto imperfectivo; relação temporal e função dependem do contexto. Voz passiva não identifica Deus como agente. Caso nominativo não é inerentemente enfático; pronome explícito pode ter destaque discursivo porque o verbo já marca pessoa. Crase καί + ἐγώ não significa lexicalmente eu mesmo.
João 1:31-33 não estabelece ausência de contato pessoal entre João e Jesus. Distinga reconhecimento messiânico pelo sinal de Deus e familiaridade anterior desconhecida. João 1:33 menciona Espírito Santo, não fogo; fogo aparece em Mateus 3:11 e Lucas 3:16. Não misture passagens sob uma referência só.
Não universalize o papel histórico-redentivo do Batista como se todos desempenhassem a mesma missão; indique analogias pastorais. Não declare uma posição sacramental controversa como consequência lexical de João 1:31.
Referências confessionais específicas só podem usar a base verificada abaixo; omita as demais, sem substituir por uma citação inventada. Referências bíblicas devem dizer o que os textos realmente sustentam. Citação literal requer texto conferido; paráfrases devem ser identificadas. Não chame autoridade de inquestionável a partir de um pronome.
Use Questões interpretativas em vez de negar genericamente ambiguidades. Apresente alternativas, evidência, escolha e limites. Propostas de tradução são rascunhos, nunca tradução oficial. Não alegue aparato ou obra paga não acessada.`
const CONFESSIONAIS = [
  { id:'WSC-1', obra:'Breve Catecismo de Westminster', pergunta:1, textoOriginal:'Man’s chief end is to glorify God, and to enjoy him forever.', resumoPt:'O fim principal do homem é glorificar a Deus e desfrutá-lo para sempre (paráfrase em português).', url:'https://opc.org/sc.html' },
  { id:'WSC-7', obra:'Breve Catecismo de Westminster', pergunta:7, textoOriginal:'The decrees of God are, his eternal purpose, according to the counsel of his will, whereby, for his own glory, he hath foreordained whatsoever comes to pass.', resumoPt:'Os decretos de Deus são seu propósito eterno, conforme o conselho de sua vontade, para sua glória (paráfrase resumida).', url:'https://opc.org/sc.html' }
]
const HERMENEUTICA = `Hermenêutica comum às modalidades, sem oração, apelo devocional ou sermão. Desenvolva seções: Sentido no contexto original; Princípios interpretativos; Relação canônica (referências e como sustentam a relação); Síntese teológica legitimamente derivada; Questões interpretativas e limites; Ponte para aplicação (princípios, sem exortação pessoal). Preserve a singularidade histórico-redentiva e distinga o que o versículo afirma do que outras passagens acrescentam.`
function tarefaHomiletica(modalidade) {
  const formatos = {
    estudo:'Estudo bíblico completo: título, objetivo, texto e contexto, ideia central, roteiro de observação/interpretação com perguntas e respostas orientadoras, relações canônicas explicadas, aplicações pessoais e comunitárias identificadas, síntese e sugestões para discussão. Não apenas três perguntas genéricas.',
    devocional:'Devocional completo: título, texto e contexto breve, verdade central, meditação fiel à passagem, reflexão pessoal, aplicações concretas sem prometer o que o texto não promete, perguntas para reflexão e oração final. Distinguir interpretação e aplicação; não transformar o leitor em João Batista.',
    sermao:'Esboço expositivo de sermão desenvolvido: título, texto, contexto, proposição central, objetivo pastoral, introdução sem história inventada apresentada como real, divisões que brotem do argumento do texto, explicação e sustentação bíblica de cada ponto, aplicações identificadas, transições, conclusão e apelo coerente. Inclua um roteiro pregável com conteúdo em cada divisão, não só títulos. Ilustrações hipotéticas devem ser identificadas. Não imponha três pontos se o texto pede outra estrutura.'
  }
  return `${formatos[modalidade]} Fundamente exclusivamente nas bases revisadas e nos textos conferidos. Não repita a análise palavra por palavra; traduza seus resultados em ensino pastoral sem apagar limites da evidência.`
}
function referenciasCitadas(texto, catalogo) {
  const livros = [...new Set(catalogo.map(v=>v.bookName))].sort((a,b)=>b.length-a.length)
  const resultados = new Map()
  for (const livro of livros) {
    const nome = livro.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')
    const re = new RegExp(`\\b${nome}\\s+(\\d+):(\\d+)(?:\\s*[-–]\\s*(\\d+))?`,'giu')
    for (const m of texto.matchAll(re)) {
      const inicio = Number(m[2]), fim = Math.min(Number(m[3] || m[2]),inicio+29)
      for (let verso=inicio; verso<=fim; verso++) {
        const key = `${livro} ${m[1]}:${verso}`
        const row = catalogo.find(v=>v.bookName===livro && v.chapter===Number(m[1]) && v.verse===verso)
        resultados.set(key,{referencia:key,texto:row?.text || null,disponivel:!!row})
      }
    }
  }
  return [...resultados.values()]
}
function validarTexto(texto) {
  if (typeof texto !== 'string' || texto.trim().length < 50) throw new Error('Relatório incompleto.')
  // Bloqueios estreitos: não substituem a revisão contextual nem rejeitam
  // explicações que mencionem explicitamente a falácia para corrigi-la.
  if (/aoristo(?:(?!\bnão\b)[^.\n]){0,100}(?:indica|descreve|significa)\s+(?:uma\s+)?ação pontual/i.test(texto)) throw new Error('Aoristo reduzido a ação pontual.')
  if (/Confissão(?: de Fé)?(?: de)? Westminster[^.\n]{0,100}fim principal/i.test(texto)) throw new Error('Catecismo atribuído à Confissão.')
  if (/(?:Espírito Santo e (?:com )?fogo|Espírito Santo e com fogo)\s*\(João\s+1:33\)/i.test(texto)) throw new Error('Conteúdo não corresponde a João 1:33.')
}
module.exports = { REGRAS, CONFESSIONAIS, HERMENEUTICA, tarefaHomiletica, referenciasCitadas, validarTexto }
