// Mapeamento determinístico conforme README do MorphGNT/SBLGNT (CC-BY-SA).
const categorias = { 'A-':'adjetivo', 'C-':'conjunção', 'D-':'advérbio', 'I-':'interjeição', 'N-':'substantivo', 'P-':'preposição', RA:'artigo definido', RD:'pronome demonstrativo', RI:'pronome interrogativo/indefinido', RP:'pronome pessoal', RR:'pronome relativo', 'V-':'verbo', 'X-':'partícula' }
const mapas = [ {'1':'1ª pessoa','2':'2ª pessoa','3':'3ª pessoa'}, {P:'presente',I:'imperfeito',F:'futuro',A:'aoristo',X:'perfeito',Y:'pluperfeito'}, {A:'voz ativa',M:'voz média',P:'voz passiva'}, {I:'indicativo',D:'imperativo',S:'subjuntivo',O:'optativo',N:'infinitivo',P:'particípio'}, {N:'nominativo',G:'genitivo',D:'dativo',A:'acusativo'}, {S:'singular',P:'plural'}, {M:'masculino',F:'feminino',N:'neutro'}, {C:'comparativo',S:'superlativo'} ]
function descreverMorfologiaGrega(classe, codigo) {
  if (!categorias[classe] || typeof codigo !== 'string' || codigo.length !== 8 || [...codigo].some((c,i)=>c!=='-' && !mapas[i][c])) return null
  return [categorias[classe], ...[...codigo].map((c,i)=>mapas[i][c]).filter(Boolean)].join('; ')
}
module.exports = { descreverMorfologiaGrega }
