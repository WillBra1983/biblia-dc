// Exporta as mesmas bases locais usadas pelo Strong, sem modificar os bancos.
const fs = require('node:fs')
const path = require('node:path')
const zlib = require('node:zlib')
const { DatabaseSync } = require('node:sqlite')
const { createHash } = require('node:crypto')
const entradas = {}
console.log('Preparando exportação lexical em partes...')
const entrada = code => entradas[code] ||= { strong: code, fontes: [], ocorrencias: { totalTokens: 0, referencias: [] } }
const abrir = arquivo => new DatabaseSync(path.resolve('public', arquivo), { readOnly: true })
const nt = abrir('nt_prova.sqlite')
const ot = abrir('ot_strong.sqlite')
const sb = abrir('stepbible_lexicon.sqlite')
const ptNome = fs.readFileSync('public/lexicon_ptbr_current.txt', 'utf8').trim()
if (path.basename(ptNome) !== ptNome) throw new Error('Ponteiro de léxico inválido.')
const pt = abrir(ptNome)
console.log('Bancos locais abertos.')
for (const row of nt.prepare('SELECT * FROM strong_greek').iterate()) entrada(row.strong).fontes.push({ fonte: 'Strong grego — banco do aplicativo', dados: row })
for (const row of ot.prepare('SELECT * FROM strong_hebrew').iterate()) entrada(row.strong_code).fontes.push({ fonte: 'Strong hebraico — banco do aplicativo', dados: row })
for (const row of sb.prepare('SELECT * FROM stepbible_lexicon').iterate()) {
  for (const code of [...new Set(String(row.strongs_unified || row.strongs_extended || '').match(/[GH]\d+/g) || [])]) entrada(code).fontes.push({ fonte: `STEPBible — ${row.source}`, dados: row })
}
for (const row of pt.prepare('SELECT * FROM lexicon_ptbr').iterate()) entrada(row.strong_code).fontes.push({ fonte: 'Léxico PT-BR — edição local do aplicativo', dados: row })
console.log('Léxicos lidos; preparando BDB e concordâncias.')
for (const row of ot.prepare('SELECT * FROM lexical_index').iterate()) {
  const codes = String(row.strong_code || '').match(/[GH]\d+/g) || []
  const bdb = row.bdb ? ot.prepare('SELECT * FROM bdb_entries WHERE entry_id=?').get(row.bdb) : null
  for (const code of codes) {
    entrada(code).fontes.push({ fonte: 'Índice lexical hebraico (inclui referências BDB/TWOT)', dados: row })
    if (bdb) entrada(code).fontes.push({ fonte: 'BDB — entrada local', dados: bdb })
  }
}
for (const [db, tabela, coluna, offset] of [[nt,'nt_tokens','book_num',39],[ot,'ot_tokens','book_id',0]]) {
  for (const row of db.prepare(`SELECT ${coluna} livro, chapter, verse, strong_code FROM ${tabela} WHERE strong_code IS NOT NULL`).iterate()) {
    for (const code of [...new Set(String(row.strong_code).match(/[GH]\d+/g) || [])]) {
      const occ = entrada(code).ocorrencias
      occ.totalTokens++
      const ref = `${row.livro + offset}:${row.chapter}:${row.verse}`
      if (occ.referencias.length < 6 && !occ.referencias.includes(ref)) occ.referencias.push(ref)
    }
  }
}
for (const db of [nt,ot,sb,pt]) db.close()
console.log('Concordâncias prontas; gravando partes compactadas.')
const pasta = 'functions/src/data/originais'
const shards = {}
for (const [code, dados] of Object.entries(entradas)) {
  const shard = createHash('sha256').update(code).digest('hex').slice(0,2)
  ;(shards[shard] ||= {})[code] = dados
}
fs.mkdirSync(path.join(pasta,'lexicos'),{recursive:true})
const revisao = createHash('sha256')
for (const [id, dados] of Object.entries(shards).sort(([a],[b])=>a.localeCompare(b))) {
  const json = JSON.stringify(dados)
  revisao.update(id).update(json)
  fs.writeFileSync(path.join(pasta,'lexicos',`${id}.json.gz`),zlib.gzipSync(json,{level:9}))
}
// Remove apenas o artefato monolítico produzido pela versão anterior deste exportador.
const antigo = path.resolve(pasta,'lexicos.json.gz')
if (fs.existsSync(antigo)) fs.unlinkSync(antigo)
fs.writeFileSync(path.join(pasta, 'lexicos-revisao.json'), JSON.stringify({ revisao: revisao.digest('hex') }))
console.log(`Léxicos exportados: ${Object.keys(entradas).length} códigos; fontes e ocorrências preservadas.`)
