// Exportação mecânica dos bancos já distribuídos pelo aplicativo. Não altera os SQLite.
const fs = require('node:fs')
const path = require('node:path')
const zlib = require('node:zlib')
const { DatabaseSync } = require('node:sqlite')
const { createHash } = require('node:crypto')
const pasta = path.resolve('functions/src/data/originais')
fs.mkdirSync(pasta, { recursive: true })
const manifesto = {}
for (const [arquivo, tabela, coluna, offset] of [['public/nt_prova.sqlite','nt_tokens','book_num',39],['public/ot_strong.sqlite','ot_tokens','book_id',0]]) {
  const db = new DatabaseSync(arquivo, { readOnly: true })
  for (const { livro } of db.prepare(`SELECT DISTINCT ${coluna} livro FROM ${tabela}`).all()) {
    const versos = {}
    const campos = offset ? 'chapter, verse, token_idx, text, lemma, pos, parsing, strong_code' : 'chapter, verse, token_idx, text, lemma_raw, morph, strong_code'
    for (const row of db.prepare(`SELECT ${campos} FROM ${tabela} WHERE ${coluna}=? ORDER BY chapter,verse,token_idx`).all(livro)) {
      const chave = `${row.chapter}_${row.verse}`
      ;(versos[chave] ||= []).push({ ordem: row.token_idx, palavra: row.text, lema: row.lemma || row.lemma_raw, classe: row.pos || '', morfologia: row.parsing || row.morph, strong: row.strong_code || '' })
    }
    const dados = { fonte: offset ? 'MorphGNT/SBLGNT; Strong: STEPBible TAGNT (CC BY 4.0)' : 'Banco hebraico/aramaico local: Open Scriptures Hebrew Bible e índices Strong', versos }
    const json = JSON.stringify(dados)
    const id = livro + offset
    fs.writeFileSync(path.join(pasta, `${id}.json.gz`), zlib.gzipSync(json, { level: 9 }))
    manifesto[id] = createHash('sha256').update(json).digest('hex')
  }
  db.close()
}
fs.writeFileSync(path.join(pasta, 'manifesto.json'), JSON.stringify(manifesto, null, 2))
console.log(`Originais exportados: ${Object.keys(manifesto).length} livros; bancos de origem preservados.`)
