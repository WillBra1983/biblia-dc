// Teste opt-in: API real, chave existente somente em memória; banco simulado.
// Não publica relatórios experimentais nem altera o acervo ou contas.
const fs = require('node:fs'), vm = require('node:vm'), path = require('node:path')
const { execFileSync } = require('node:child_process')
async function testar() {
  const acesso = execFileSync(process.execPath, ['node_modules/firebase-tools/lib/bin/firebase.js','functions:secrets:access','GEMINI_API_KEY'], {encoding:'utf8', timeout:90000, stdio:['ignore','pipe','pipe']})
  const keyReal = acesso.trim()
  if (keyReal.length < 8 || /\r|\n/.test(keyReal)) throw new Error('Não foi possível carregar a chave existente com segurança.')
  const fixture = fs.readFileSync('scripts/test-analise-textual-servidor.cjs','utf8').split('vm.runInNewContext(fs.readFileSync(arquivo')[0].replace("value: () => 'CHAVE-FICTICIA-TESTE'",'value: () => keyReal')
  const scope = {require, console, AbortSignal, Date, Set, structuredClone, keyReal, globalFetch:fetch, setTimeout}
  vm.runInNewContext(fixture + `\ncontext.fetch = async (...args) => {
    const response = await globalFetch(...args)
    const body = await response.clone().json()
    const c = body.candidates?.[0]
    console.log('API real:', JSON.stringify({status:response.status,conclusao:c?.finishReason,recuperacao:c?.urlContextMetadata || c?.url_context_metadata,tokens:body.usageMetadata?.totalTokenCount,caracteres:c?.content?.parts?.map(p=>p.text || '').join('').length}))
    return response
  }; context.console=console; scopeContext=context; scopeFile=arquivo;`,scope)
  vm.runInNewContext(fs.readFileSync(scope.scopeFile,'utf8'),scope.scopeContext)
  if (process.argv.includes('--strong')) {
    const baseRequire = scope.scopeContext.require
    const contextoStrong = {...scope.scopeContext,exports:{},require:nome => {
      if (nome === 'firebase-functions/v2') return {logger:{info(){},warn(){},error(){}}}
      const modulo = baseRequire(nome)
      if (nome === './firebaseAdmin') modulo.database.ServerValue = {TIMESTAMP:Date.now()}
      return modulo
    }}
    vm.runInNewContext(fs.readFileSync('functions/src/geminiProxy.js','utf8'),contextoStrong)
    const resposta = await contextoStrong.exports.geminiGenerateContent({auth:{uid:'usuario'},data:{model:'gemini-2.5-flash',body:{pesquisaBiblicaObrigatoria:true,contents:[{role:'user',parts:[{text:'Explique o lema G1492 οἶδα, sua forma pluperfeita e o uso em João 1:31. Não confunda dado morfológico e interpretação contextual.'}]}],generationConfig:{maxOutputTokens:8192,responseMimeType:'application/json',responseSchema:{type:'OBJECT',properties:{sentido:{type:'STRING'}},required:['sentido']}}}}})
    if (!resposta.ok || resposta.data.pesquisaBiblica.fontes.length < 2) throw new Error('Strong sem pesquisa confirmada.')
    const estruturado = JSON.parse(resposta.data.candidates[0].content.parts.map(p=>p.text || '').join(''))
    if (!estruturado.sentido || typeof estruturado.sentido !== 'string') throw new Error('Formato estruturado do Strong inválido.')
    console.log('STRONG REAL CONCLUÍDO:',JSON.stringify({fontes:resposta.data.pesquisaBiblica.fontes.map(f=>f.url)}))
    return
  }
  const req = {auth:{uid:'usuario'},data:{livro:43,capitulo:1,versiculos:[31],etapa:'exegese',modalidade:'estudo'}}
  const resultado = await scope.scopeContext.exports.gerarAnaliseTextual(req)
  if (!resultado.relatorio.texto.includes('Palavra 16')) throw new Error('Relatório sem todas as 16 palavras.')
  console.log('EXEGESE REAL CONCLUÍDA:',JSON.stringify({caracteres:resultado.relatorio.texto.length,fontes:resultado.relatorio.pesquisa.fontes.map(f=>f.url),pluperfeito:resultado.relatorio.texto.includes('pluperfeito')}))
  const reutilizado = await scope.scopeContext.exports.gerarAnaliseTextual(req)
  if (reutilizado.relatorio.id !== resultado.relatorio.id) throw new Error('Reutilização incorreta.')
  console.log('Cache confirmado. Banco real não foi alterado.')
  if (process.argv.includes('--completo')) {
    const tarefas = [{etapa:'hermeneutica',modalidade:'estudo'},{etapa:'homiletica',modalidade:'estudo'},...(process.argv.includes('--modalidades') ? [{etapa:'homiletica',modalidade:'sermao'},{etapa:'homiletica',modalidade:'devocional'}] : [])]
    for (const {etapa,modalidade} of tarefas) {
      const pedido = {...req,data:{...req.data,etapa,modalidade}}
      let material
      for (let tentativa = 1; tentativa <= 3; tentativa++) {
        try { material = await scope.scopeContext.exports.gerarAnaliseTextual(pedido); break }
        catch (e) { if (e.code !== 'unavailable' || tentativa === 3) throw e; console.log('Nova tentativa controlada:',etapa,tentativa + 1) }
      }
      if (!material.relatorio.texto || material.relatorio.texto.length < 200 || material.relatorio.pesquisa?.fontes?.length < 2) throw new Error('Material incompleto ou sem fontes: '+etapa)
      if (material.relatorio.revisaoAutomatica?.tipo !== 'automatica') throw new Error('Material sem revisão registrada.')
      if (modalidade === 'sermao' && !/proposi[çc][ãa]o/i.test(material.relatorio.texto)) throw new Error('Sermão sem proposição.')
      console.log('ETAPA REAL CONCLUÍDA:',JSON.stringify({etapa,modalidade,caracteres:material.relatorio.texto.length,revisao:material.relatorio.revisaoAutomatica.tipo,fontes:material.relatorio.pesquisa.fontes.map(f=>f.url)}))
      const cache = await scope.scopeContext.exports.gerarAnaliseTextual(pedido)
      if (cache.relatorio.id !== material.relatorio.id) throw new Error('Reutilização incorreta: '+etapa)
      console.log('Reutilização confirmada:',etapa)
    }
  }
}
testar().catch(e=>{console.error('Teste real interrompido:',e.code || e.name || 'falha',e.stack?.split('\n').slice(1,3).join('\n'));process.exitCode=1})
