const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const path = require('node:path')
const dados = { users: { usuario: { admin: false }, admin: { admin: true } } }
let chamadas = 0, travar = false, liberar, rejeitarRevisao = false
function ref(caminho = '') {
  const partes = caminho.split('/').filter(Boolean)
  const ler = () => partes.reduce((o,k) => o?.[k], dados) ?? null
  const salvar = valor => { let o = dados; for (const k of partes.slice(0,-1)) o = o[k] ||= {}; if (valor === null) delete o[partes.at(-1)]; else o[partes.at(-1)] = structuredClone(valor) }
  return {
    child: c => ref(`${caminho}/${c}`), get: async () => ({ val: () => structuredClone(ler()) }),
    transaction: async cb => { const valor = cb(structuredClone(ler())); if (valor === undefined) return { committed: false }; salvar(valor); return { committed: true } },
    update: async updates => { for (const [k,v] of Object.entries(updates)) ref(`${caminho}/${k}`).set(v) },
    set: salvar, push: async v => salvar(v), orderByChild: () => ref(caminho), limitToLast: () => ref(caminho)
  }
}
class HttpsError extends Error { constructor(code,message) { super(message); this.code = code } }
const arquivo = path.resolve('functions/src/analiseTextual.js')
const context = {
  exports: {}, __dirname: path.dirname(arquivo), AbortSignal, Date, Set,
  require: nome => {
    if (nome === './firebaseAdmin') return { database: () => ({ ref }) }
    if (nome === 'firebase-functions/v2/https') return { onCall: (_,handler) => handler, HttpsError }
    if (nome === 'firebase-functions/params') return { defineSecret: () => ({ value: () => 'CHAVE-FICTICIA-TESTE' }) }
    if (nome.startsWith('.')) return require(path.resolve(path.dirname(arquivo),nome))
    return require(nome)
  },
  fetch: async (_,opts) => {
    chamadas++
    if (travar) { travar = false; await new Promise(resolve => { liberar = resolve }) }
    const prompt = JSON.parse(opts.body).contents[0].parts[0].text
    let texto = 'Relatório simulado para teste automatizado, sem acesso à API e sem conteúdo doutrinário real.'
    if (prompt.includes('REVISÃO EDITORIAL OBRIGATÓRIA')) {
      const payload = JSON.parse(prompt.slice(prompt.lastIndexOf('\n{') + 1))
      texto = JSON.stringify({aprovado:!rejeitarRevisao,problemas:[],materiais:payload.materiais})
    } else if (prompt.includes('SOMENTE JSON')) {
      const payload = JSON.parse(prompt.slice(prompt.lastIndexOf('\n{') + 1))
      texto = JSON.stringify(Object.fromEntries(payload.faltantes.map(u => [u.id, u.etapa === 'exegese' ? { introducao: texto, palavras: payload.originais.selecionados.find(v=>v.verso===u.verso).palavras.map((p,i)=>({ ordem:i+1, transliteracao:texto, gramatica:texto, sintaxe:texto, sentido:texto, traducao:texto })), conclusao:texto } : `${texto} Base ${u.verso}.`])))
    }
    const groundingMetadata = JSON.parse(opts.body).tools ? { webSearchQueries:['João original morfologia'], groundingChunks:[{web:{uri:'https://www.stepbible.org/lexicon',title:'STEPBible'}},{web:{uri:'https://logeion.uchicago.edu/teste',title:'Logeion'}}], groundingSupports:[{segment:{text:'Evidência documental simulada.'},groundingChunkIndices:[0,1]}] } : undefined
    return { ok: true, json: async () => ({ candidates: [{ finishReason: 'STOP', content: { parts: [{ text: texto }] }, groundingMetadata }] }) }
  }
}
vm.runInNewContext(fs.readFileSync(arquivo,'utf8'), context)
const api = context.exports
const pedido = (versiculos, etapa = 'exegese', modalidade = 'estudo') => ({ auth: { uid: 'usuario' }, data: { livro: 43, capitulo: 1, versiculos, etapa, modalidade } })
;(async () => {
  await assert.rejects(api.gerarAnaliseTextual({ data: {} }), e => e.code === 'unauthenticated')
  const longo = await api.gerarAnaliseTextual(pedido([19,20]))
  assert.equal(chamadas,6) // pesquisa + lote + revisão, pesquisa + síntese + revisão
  assert.equal(longo.relatorio.pesquisa.fontes.length,2)
  const curto = await api.gerarAnaliseTextual(pedido([19]))
  assert.equal(chamadas,6) // reutiliza base pesquisada e revisada, sem API
  assert.equal(curto.bases[0].id,longo.bases[0].id)
  await api.gerarAnaliseTextual(pedido([19], 'exegese', 'devocional'))
  assert.equal(chamadas,6)
  await api.avaliarAnaliseTextual({ auth:{uid:'usuario'}, data:{id:curto.bases[0].id, positivo:false} })
  assert.equal(dados.analiseTextual.materiais[curto.bases[0].id].estado,'disponivel')
  await assert.rejects(api.revisarAnaliseTextual({auth:{uid:'usuario'},data:{acao:'invalidar',id:curto.bases[0].id}}), e=>e.code==='permission-denied')
  await api.revisarAnaliseTextual({auth:{uid:'admin'},data:{acao:'invalidar',id:curto.bases[0].id}})
  assert.equal(dados.analiseTextual.materiais[curto.bases[0].id].estado,'invalidado')
  await api.gerarAnaliseTextual(pedido([19]))
  assert.equal(chamadas,9)
  travar = true
  const primeiro = api.gerarAnaliseTextual(pedido([21]))
  while (!liberar) await new Promise(resolve=>setTimeout(resolve,1))
  await assert.rejects(api.gerarAnaliseTextual(pedido([21])), e=>e.code==='aborted')
  liberar(); await primeiro
  assert.equal(chamadas,12)
  await api.gerarAnaliseTextual(pedido([19],'hermeneutica'))
  assert.equal(chamadas,15)
  await api.gerarAnaliseTextual(pedido([19],'homiletica','devocional'))
  assert.equal(chamadas,18)
  await api.gerarAnaliseTextual(pedido([19],'homiletica','devocional'))
  assert.equal(chamadas,18)
  await api.gerarAnaliseTextual(pedido([19],'homiletica','sermao'))
  assert.equal(chamadas,21)
  assert.equal(curto.relatorio.revisaoAutomatica.tipo,'automatica')
  rejeitarRevisao = true
  await assert.rejects(api.gerarAnaliseTextual(pedido([22])),e=>e.code==='unavailable')
  assert.ok(!Object.values(dados.analiseTextual.materiais).some(m=>m.verso===22))
  assert.equal(Object.keys(dados.analiseTextual.locks).length,0)
  console.log('Servidor (API simulada): cache, lote, concorrência, etapas, votos e exclusividade administrativa passaram. Nenhuma cobrança real.')
})().catch(e=>{console.error(e);process.exitCode=1})
