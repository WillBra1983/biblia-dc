import { Alert, Box, Link, Typography } from '@mui/material'
export default function PesquisaBiblicaFontes({ pesquisa }) {
  if (!pesquisa) return <Alert severity="info" sx={{ my: 2 }}>Material anterior à pesquisa rastreável: não há registro das páginas consultadas nesta versão.</Alert>
  const fontes = pesquisa.fontes || []
  const seguro = raw => { try { const u = new URL(raw); return u.protocol === 'https:' && !u.username && !u.password } catch { return false } }
  return <Box component="details" open sx={{ my: 2, p: 1, border: 1, borderColor: 'divider', borderRadius: 1 }}>
    <summary>Fontes efetivamente consultadas ({fontes.length})</summary>
    <Typography variant="caption">Pesquisa em {new Date(pesquisa.consultadoEm).toLocaleString('pt-BR')}. Links e evidências não substituem revisão acadêmica.</Typography>
    {fontes.filter(f=>seguro(f.url)).map(f=><Typography key={f.url} sx={{ my: 1 }}><Link href={f.url} target="_blank" rel="noopener noreferrer">{f.titulo}</Link></Typography>)}
    {(pesquisa.evidencias || []).map((e,i)=><Box key={i} sx={{ my: 1 }}><Typography variant="body2">{e.texto}</Typography>{(e.fontes || []).filter(seguro).map((url,n)=><Link key={url} href={url} target="_blank" rel="noopener noreferrer" sx={{ mr: 1 }}>Fonte {n+1}</Link>)}</Box>)}
    {!!pesquisa.consultas?.length && <Typography variant="caption" sx={{ display:'block' }}>Consultas: {pesquisa.consultas.join(' • ')}</Typography>}
    {!!pesquisa.sugestoesHtml && <Box component="iframe" title="Sugestões da pesquisa Google" sandbox="allow-popups allow-popups-to-escape-sandbox" referrerPolicy="no-referrer" srcDoc={`<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src https: data:; script-src 'none'">${pesquisa.sugestoesHtml}`} sx={{ width:'100%', height:180, border:0, mt:1 }} />}
  </Box>
}
