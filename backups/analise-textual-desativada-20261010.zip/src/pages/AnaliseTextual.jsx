import { useEffect, useState } from 'react'
import { Alert, Box, Button, Checkbox, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, MenuItem, Paper, Stack, TextField, Typography } from '@mui/material'
import ThumbUpOutlined from '@mui/icons-material/ThumbUpOutlined'
import ThumbDownOutlined from '@mui/icons-material/ThumbDownOutlined'
import { useSearchParams } from 'react-router-dom'
import { livros } from '../data/biblia'
import { buscarCapitulo } from '../services/bibliaService'
import { useFirebaseAuth } from '../contexts/FirebaseAuthContext'
import { useEhAdmin } from '../hooks/useEhAdmin'
import EditorialProse from '../components/EditorialProse'
import PesquisaBiblicaFontes from '../components/PesquisaBiblicaFontes'
import { gerarAnalise, avaliarAnalise, revisarAnalise } from '../services/analiseTextualService'
const modalidades = { estudo: 'Estudo bíblico', devocional: 'Devocional', sermao: 'Esboço de sermão' }
const etapas = { exegese: 'Exegese', hermeneutica: 'Hermenêutica', homiletica: 'Homilética' }
export default function AnaliseTextual() {
  const [query] = useSearchParams()
  const { user } = useFirebaseAuth()
  const { ehAdmin } = useEhAdmin(user?.uid || null)
  const [modalidade, setModalidade] = useState('estudo')
  const [livro, setLivro] = useState(Number(query.get('livro')) || 43)
  const [capitulo, setCapitulo] = useState(Number(query.get('capitulo')) || 1)
  const [versiculos, setVersiculos] = useState((query.get('versiculos') || '').split(',').map(Number).filter(n => n > 0))
  const [rows, setRows] = useState([])
  const [selecionando, setSelecionando] = useState(false)
  const [carregandoTexto, setCarregandoTexto] = useState(false)
  const [busy, setBusy] = useState('')
  const [erro, setErro] = useState('')
  const [aviso, setAviso] = useState('')
  const [relatorios, setRelatorios] = useState({})
  const [revisoes, setRevisoes] = useState(null)
  const [materialRevisao, setMaterialRevisao] = useState(null)
  const [confirmar, setConfirmar] = useState(false)
  useEffect(() => {
    let ativo = true
    setRows([]); setCarregandoTexto(true)
    buscarCapitulo(livro, capitulo).then(data => { if (ativo) setRows(data) }).catch(e => { if (ativo) setErro(e.message) }).finally(() => { if (ativo) setCarregandoTexto(false) })
    return () => { ativo = false }
  }, [livro, capitulo])
  async function executar(acao) {
    setErro(''); setAviso(''); setBusy('ação')
    try { await acao() } catch (e) { setErro(e.message || 'Não foi possível concluir.') } finally { setBusy('') }
  }
  async function gerar(etapa) {
    setErro(''); setBusy(etapa)
    try {
      const result = await gerarAnalise({ modalidade, etapa, livro, capitulo, versiculos })
      setRelatorios(prev => ({ ...prev, [etapa]: result }))
    } catch (e) { setErro(e.message || 'Falha na geração.') } finally { setBusy('') }
  }
  async function gerarCompleto() {
    setErro(''); setBusy('completo')
    try {
      for (const etapa of Object.keys(etapas)) {
        const result = await gerarAnalise({ modalidade, etapa, livro, capitulo, versiculos })
        setRelatorios(prev => ({ ...prev, [etapa]: result }))
      }
    } catch (e) { setErro(e.message || 'Não foi possível concluir. As etapas prontas serão reutilizadas ao tentar novamente.') } finally { setBusy('') }
  }
  const referencia = `${livros.find(l => l.id === livro)?.nome || ''} ${capitulo}:${[...versiculos].sort((a,b) => a-b).join(', ')}`
  function avaliar(id, positivo) { executar(async () => { await avaliarAnalise(id, positivo); setAviso(positivo ? 'Avaliação registrada.' : 'O administrador recebeu um aviso na fila de revisão. O material não foi excluído.') }) }
  return <Box sx={{ maxWidth: 960, mx: 'auto', p: 2, pb: 6 }}>
    <Typography variant="h4" sx={{ mb: 2 }}>Análise textual</Typography>
    <Alert severity="info" sx={{ mb: 2 }}>Exegese e hermenêutica são reutilizadas entre modalidades. A homilética adapta as aplicações. Somente o administrador pode invalidar um material.</Alert>
    {!user && <Alert severity="warning">Conecte-se para gerar e avaliar os relatórios.</Alert>}
    {erro && <Alert severity="error" sx={{ my: 2 }}>{erro}</Alert>}
    {aviso && <Alert severity="success" sx={{ my: 2 }}>{aviso}</Alert>}
    <TextField select fullWidth label="Finalidade" value={modalidade} disabled={!!busy} onChange={e => { setModalidade(e.target.value); setRelatorios(prev => ({ ...prev, homiletica: undefined })) }} sx={{ my: 2 }}>{Object.entries(modalidades).map(([id, nome]) => <MenuItem key={id} value={id}>{nome}</MenuItem>)}</TextField>
    <Button variant="outlined" disabled={!!busy} onClick={() => setSelecionando(true)}>Abrir Bíblia e escolher versículos</Button>
    <Typography sx={{ my: 2 }}>{versiculos.length ? referencia : 'Escolha o texto bíblico para analisar.'}</Typography>
    <Stack direction="row" useFlexGap flexWrap="wrap" spacing={1} sx={{ mb: 2 }}>{Object.entries(etapas).map(([id, nome]) => <Button key={id} variant="contained" disabled={!!busy || !user || !versiculos.length || carregandoTexto} onClick={() => gerar(id)}>{busy === id ? <CircularProgress size={20} color="inherit" /> : nome}</Button>)}</Stack>
    <Button variant="outlined" disabled={!!busy || !user || !versiculos.length || carregandoTexto} onClick={gerarCompleto} sx={{ mb: 2 }}>Gerar material completo — {modalidades[modalidade]}</Button>
    {busy && <Typography role="status">Consultando o acervo; para novos materiais, pesquisando fontes, preparando e revisando o conteúdo. Pode levar alguns minutos…</Typography>}
    {Object.entries(relatorios).filter(([,r]) => r).map(([etapa, result]) => <Paper key={etapa} sx={{ my: 2, p: 2 }}>
      <Typography variant="h5">{etapas[etapa]}</Typography>
      <Typography variant="caption" component="p" sx={{ my: 1 }}>{result.relatorio.revisaoAutomatica ? 'Conteúdo submetido a revisão automática. Não substitui revisão acadêmica ou pastoral humana.' : 'Versão anterior à revisão automática de conteúdo.'}</Typography>
      {etapa === 'exegese' && result.originais && <Box component="details" sx={{ my: 2 }}><summary>Dados do original — fonte e códigos conferíveis</summary><Typography variant="caption">{result.originais.fonte}. As explicações e propostas de tradução do relatório são interpretações para revisão, não uma nova tradução oficial.</Typography>{result.originais.selecionados.map(verso => <Box key={verso.verso} sx={{ overflowX: 'auto', my: 1 }}><Typography>Versículo {verso.verso}</Typography><Box component="table" sx={{ width: '100%', '& th, & td': { borderBottom: '1px solid', borderColor: 'divider', p: 1, textAlign: 'left' } }}><thead><tr><th>Palavra</th><th>Lema</th><th>Strong</th><th>Morfologia da base</th></tr></thead><tbody>{verso.palavras.map(p => <tr key={p.ordem}><td>{p.palavra}</td><td>{p.lema}</td><td>{p.strong || 'Não disponível'}</td><td>{p.morfologia}</td></tr>)}</tbody></Box></Box>)}</Box>}
      <EditorialProse text={result.relatorio.texto} />
      <PesquisaBiblicaFontes pesquisa={result.relatorio.pesquisa} />
      <Stack direction="row" spacing={1}><Button disabled={!!busy} startIcon={<ThumbUpOutlined />} onClick={() => avaliar(result.relatorio.id, true)}>Curtir</Button><Button disabled={!!busy} startIcon={<ThumbDownOutlined />} onClick={() => avaliar(result.relatorio.id, false)}>Solicitar revisão</Button></Stack>
      {result.bases?.map(base => <Box component="details" key={base.id} sx={{ mt: 1 }}><summary>Base reutilizável: {base.referencia}</summary><EditorialProse text={base.texto} /><PesquisaBiblicaFontes pesquisa={base.pesquisa} /><Button disabled={!!busy} onClick={() => avaliar(base.id, false)}>Solicitar revisão deste versículo</Button></Box>)}
    </Paper>)}
    {ehAdmin && <Box sx={{ mt: 3 }}><Button disabled={!!busy} onClick={() => executar(async () => setRevisoes((await revisarAnalise('listar')).itens))}>Avisos de revisão — administrador</Button>
      {revisoes?.length === 0 && <Typography>Nenhum aviso pendente.</Typography>}
      {revisoes?.map(item => <Button key={item.id} disabled={!!busy} onClick={() => executar(async () => setMaterialRevisao((await revisarAnalise('ler', item.id)).material))}>{item.referencia} — {etapas[item.etapa]}</Button>)}
    </Box>}
    <Dialog open={selecionando} onClose={() => setSelecionando(false)} fullWidth maxWidth="sm"><DialogTitle>Escolher texto bíblico</DialogTitle><DialogContent>
      <Stack direction="row" spacing={1} sx={{ my: 2 }}><TextField select fullWidth label="Livro" value={livro} onChange={e => { setLivro(Number(e.target.value)); setCapitulo(1); setVersiculos([]); setRelatorios({}) }}>{livros.map(l => <MenuItem key={l.id} value={l.id}>{l.nome}</MenuItem>)}</TextField><TextField label="Capítulo" type="number" value={capitulo} inputProps={{ min: 1 }} onChange={e => { setCapitulo(Math.max(1, Number(e.target.value) || 1)); setVersiculos([]); setRelatorios({}) }} /></Stack>
      {carregandoTexto && <CircularProgress />}
      {!carregandoTexto && !rows.length && <Alert severity="warning">Capítulo não encontrado.</Alert>}
      {rows.map((row, i) => <FormControlLabel key={i} sx={{ alignItems: 'flex-start', display: 'flex', my: 1 }} control={<Checkbox checked={versiculos.includes(i + 1)} disabled={!versiculos.includes(i + 1) && versiculos.length >= 30} onChange={e => { setVersiculos(prev => e.target.checked ? [...prev, i + 1] : prev.filter(v => v !== i + 1)); setRelatorios({}) }} />} label={`${i + 1}. ${row.texto}`} />)}
    </DialogContent><DialogActions><Button disabled={!versiculos.length || carregandoTexto} onClick={() => setSelecionando(false)}>Usar seleção e retornar</Button></DialogActions></Dialog>
    <Dialog open={!!materialRevisao} onClose={() => { setMaterialRevisao(null); setConfirmar(false) }} fullWidth maxWidth="md"><DialogTitle>Revisar {materialRevisao?.referencia}</DialogTitle><DialogContent><EditorialProse text={materialRevisao?.texto || ''} />{confirmar && <Alert severity="warning">Invalidar retirará esta versão e seus derivados do reaproveitamento e permitirá uma nova geração. O histórico será preservado.</Alert>}</DialogContent><DialogActions>
      <Button disabled={!!busy} onClick={() => executar(async () => { await revisarAnalise('manter', materialRevisao.id); setMaterialRevisao(null); setRevisoes((await revisarAnalise('listar')).itens) })}>Manter material</Button>
      <Button color="error" disabled={!!busy} onClick={() => confirmar ? executar(async () => { await revisarAnalise('invalidar', materialRevisao.id); setMaterialRevisao(null); setConfirmar(false); setRelatorios({}); setRevisoes((await revisarAnalise('listar')).itens) }) : setConfirmar(true)}>{confirmar ? 'Confirmar invalidação' : 'Invalidar e permitir nova geração'}</Button>
    </DialogActions></Dialog>
  </Box>
}
