import { getFirebaseFunctions } from '../config/firebaseRuntime'
async function chamar(nome, dados) {
  const functions = getFirebaseFunctions()
  if (!functions) throw new Error('Firebase não configurado.')
  const { httpsCallable } = await import('firebase/functions')
  try { return (await httpsCallable(functions, nome, { timeout: 540000 })(dados)).data }
  catch (e) {
    if (String(e.code).includes('not-found')) throw new Error('A análise textual ainda precisa ser publicada no servidor para gerar relatórios.')
    throw e
  }
}
export const gerarAnalise = dados => chamar('gerarAnaliseTextual', dados)
export const avaliarAnalise = (id, positivo) => chamar('avaliarAnaliseTextual', { id, positivo })
export const revisarAnalise = (acao, id) => chamar('revisarAnaliseTextual', { acao, ...(id ? { id } : {}) })
